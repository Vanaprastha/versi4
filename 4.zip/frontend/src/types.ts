export type Row = {
  nama_desa: string;
  [key: string]: number | string;
};
