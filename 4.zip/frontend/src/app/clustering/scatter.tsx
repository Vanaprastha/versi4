export default function Scatter() {
  return (
    <div className="text-sm text-neutral-400 h-64 flex items-center justify-center">
      [Scatter plot mockup di sini — sambungkan ke hasil K-Means]
    </div>
  );
}
